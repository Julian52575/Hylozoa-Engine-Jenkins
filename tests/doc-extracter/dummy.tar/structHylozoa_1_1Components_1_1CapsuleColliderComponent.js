var structHylozoa_1_1Components_1_1CapsuleColliderComponent =
[
    [ "center1", "structHylozoa_1_1Components_1_1CapsuleColliderComponent.html#a1ac76b9cf8e373f5f84d2c34af6d0848", null ],
    [ "center2", "structHylozoa_1_1Components_1_1CapsuleColliderComponent.html#a05bfa4f68a940e7fed8d707a9ccc95e6", null ],
    [ "radius", "structHylozoa_1_1Components_1_1CapsuleColliderComponent.html#abe6667f1109018c8f346d69cae5414fe", null ]
];