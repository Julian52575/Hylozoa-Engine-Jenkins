var LayerManager_8hpp =
[
    [ "Hylozoa::LayerMask", "classHylozoa_1_1LayerMask.html", "classHylozoa_1_1LayerMask" ],
    [ "Hylozoa::LayerManager", "classHylozoa_1_1LayerManager.html", "classHylozoa_1_1LayerManager" ],
    [ "Hylozoa::LayerBit", "namespaceHylozoa.html#acc8ba0d0ab95f5bb8544181dc1cf981b", null ]
];