var structHylozoa_1_1Components_1_1Controllable =
[
    [ "isControllable", "structHylozoa_1_1Components_1_1Controllable.html#a3a464ca5b9c6e47b13414b5c7ae69b3e", null ],
    [ "keysHeld", "structHylozoa_1_1Components_1_1Controllable.html#a1eeb122527ca2a821db6f9125a408c1e", null ]
];