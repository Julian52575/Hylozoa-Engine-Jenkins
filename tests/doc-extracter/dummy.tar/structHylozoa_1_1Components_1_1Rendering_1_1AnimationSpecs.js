var structHylozoa_1_1Components_1_1Rendering_1_1AnimationSpecs =
[
    [ "currentFrame", "structHylozoa_1_1Components_1_1Rendering_1_1AnimationSpecs.html#a7dced549da1ef37c2d72634b7e3231b3", null ],
    [ "elapsedTime", "structHylozoa_1_1Components_1_1Rendering_1_1AnimationSpecs.html#ae802ef1ad6a685cb761ee4031e9afb90", null ],
    [ "frameCount", "structHylozoa_1_1Components_1_1Rendering_1_1AnimationSpecs.html#ab2679b89ec8082a6858441bbb02faa64", null ],
    [ "frameDisplacement", "structHylozoa_1_1Components_1_1Rendering_1_1AnimationSpecs.html#a140d497d05a73d1812343e742b43c0b9", null ],
    [ "frameDuration", "structHylozoa_1_1Components_1_1Rendering_1_1AnimationSpecs.html#aabe8225739755c50813eff9c5e80c62c", null ],
    [ "frameRect", "structHylozoa_1_1Components_1_1Rendering_1_1AnimationSpecs.html#a065bccae78cfffd702541d061ab7ab21", null ],
    [ "frameRectHeight", "structHylozoa_1_1Components_1_1Rendering_1_1AnimationSpecs.html#aea415526855de944da52e9d244c553a9", null ],
    [ "frameRectWidth", "structHylozoa_1_1Components_1_1Rendering_1_1AnimationSpecs.html#a06fb01aa5eefc988e3bfee311cd89966", null ]
];