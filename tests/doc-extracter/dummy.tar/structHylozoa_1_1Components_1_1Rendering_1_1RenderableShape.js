var structHylozoa_1_1Components_1_1Rendering_1_1RenderableShape =
[
    [ "RectangleSpecs", "structHylozoa_1_1Components_1_1Rendering_1_1RenderableShape_1_1RectangleSpecs.html", "structHylozoa_1_1Components_1_1Rendering_1_1RenderableShape_1_1RectangleSpecs" ],
    [ "CircleSpecs", "structHylozoa_1_1Components_1_1Rendering_1_1RenderableShape_1_1CircleSpecs.html", "structHylozoa_1_1Components_1_1Rendering_1_1RenderableShape_1_1CircleSpecs" ],
    [ "ShapeType", "structHylozoa_1_1Components_1_1Rendering_1_1RenderableShape.html#a2eb15ce444e7b8e7b25632b97f1cfbd8", [
      [ "Rectangle", "structHylozoa_1_1Components_1_1Rendering_1_1RenderableShape.html#a2eb15ce444e7b8e7b25632b97f1cfbd8ace9291906a4c3b042650b70d7f3b152e", null ],
      [ "Circle", "structHylozoa_1_1Components_1_1Rendering_1_1RenderableShape.html#a2eb15ce444e7b8e7b25632b97f1cfbd8a30954d90085f6eaaf5817917fc5fecb3", null ]
    ] ],
    [ "outlineColor", "structHylozoa_1_1Components_1_1Rendering_1_1RenderableShape.html#a28542d7287a4ed927db6ead037e4201c", null ],
    [ "outlineThickness", "structHylozoa_1_1Components_1_1Rendering_1_1RenderableShape.html#aeedbc5e3eb63ddc8adf9b109207e5712", null ],
    [ "specs", "structHylozoa_1_1Components_1_1Rendering_1_1RenderableShape.html#a38990939852107728df2156e3a471baf", null ],
    [ "type", "structHylozoa_1_1Components_1_1Rendering_1_1RenderableShape.html#a839d2e648b1aced6f9835e886b65ab15", null ]
];