var structHylozoa_1_1Components_1_1Rendering_1_1Sprite =
[
    [ "scale", "structHylozoa_1_1Components_1_1Rendering_1_1Sprite.html#ae7c1ebbde2b1a097ce9949ef45ecdba7", null ],
    [ "textureName", "structHylozoa_1_1Components_1_1Rendering_1_1Sprite.html#a3256201e72a5d6b5c21233d8fdb74a95", null ]
];