var classHylozoa_1_1SDL_1_1SDL__Manager =
[
    [ "getRenderer", "classHylozoa_1_1SDL_1_1SDL__Manager.html#af9c37e6c574dc60e56717d76921c4b24", null ],
    [ "getWindow", "classHylozoa_1_1SDL_1_1SDL__Manager.html#a397348acecc10037bd8c4c3d20ea1372", null ]
];