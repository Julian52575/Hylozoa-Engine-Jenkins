var ResourceManager_8hpp =
[
    [ "Hylozoa::ResourcesManager&lt; Resource &gt;", "classHylozoa_1_1ResourcesManager.html", "classHylozoa_1_1ResourcesManager" ],
    [ "Hylozoa::FontManager", "namespaceHylozoa.html#ab785fa2822f36800b0055596dfdcddd6", null ],
    [ "Hylozoa::SoundManager", "namespaceHylozoa.html#ab9dc006b5911271611a8964152532b9d", null ],
    [ "Hylozoa::TextureManager", "namespaceHylozoa.html#adfce3a7e2cf80653fa57b601bca45d5c", null ]
];