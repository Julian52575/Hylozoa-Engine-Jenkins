var structHylozoa_1_1Components_1_1CircleColliderComponent =
[
    [ "offset", "structHylozoa_1_1Components_1_1CircleColliderComponent.html#a45db4981dd0c2fea29359a4d6c124dc0", null ],
    [ "radius", "structHylozoa_1_1Components_1_1CircleColliderComponent.html#a591f2f40ec8bf1f22786e395595269f8", null ]
];