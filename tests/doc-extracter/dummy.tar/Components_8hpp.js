var Components_8hpp =
[
    [ "deserializeIfPresent", "Components_8hpp.html#a092891d6f6357e79fa36ef9e3caed8d3", null ],
    [ "serializeIfPresent", "Components_8hpp.html#a787c374b31a2adcb51ede1e5aa57600b", null ]
];