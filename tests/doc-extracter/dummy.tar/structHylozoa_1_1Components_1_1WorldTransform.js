var structHylozoa_1_1Components_1_1WorldTransform =
[
    [ "position", "structHylozoa_1_1Components_1_1WorldTransform.html#a1dd2d4de880c9d2a86c1d615381cfc82", null ],
    [ "rotation", "structHylozoa_1_1Components_1_1WorldTransform.html#aaae2db678183bed6797eced65c917e6f", null ],
    [ "scale", "structHylozoa_1_1Components_1_1WorldTransform.html#ac30043bd453243f5fc41bdd66469a1de", null ]
];