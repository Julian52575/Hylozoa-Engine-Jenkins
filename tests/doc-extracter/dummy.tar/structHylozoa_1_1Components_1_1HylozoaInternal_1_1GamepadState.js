var structHylozoa_1_1Components_1_1HylozoaInternal_1_1GamepadState =
[
    [ "axes", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1GamepadState.html#abf84471ceee9d7b2c63e145160587d68", null ],
    [ "buttonsHeld", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1GamepadState.html#a75664f83ed98c679c1df4833e67103c4", null ],
    [ "buttonsPressed", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1GamepadState.html#a07bdd6200cc1d305c4ff156214f94d1b", null ],
    [ "buttonsReleased", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1GamepadState.html#a425cff4366ab567b6126b4b7c2fa6782", null ]
];