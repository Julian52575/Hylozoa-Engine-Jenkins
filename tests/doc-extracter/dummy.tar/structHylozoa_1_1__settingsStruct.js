var structHylozoa_1_1__settingsStruct =
[
    [ "_settingsStruct", "structHylozoa_1_1__settingsStruct.html#a4820a4998b22aca0e283a9f501e95cfc", null ],
    [ "_settingsStruct", "structHylozoa_1_1__settingsStruct.html#acbfc11c72eec9664ba32523833fdb0fb", null ],
    [ "exportToJson", "structHylozoa_1_1__settingsStruct.html#ae7201d07f0c31a38578fc602a9640e90", null ],
    [ "debugLevel", "structHylozoa_1_1__settingsStruct.html#a8fd8aa806172f0324ad487e45ce3785d", null ],
    [ "name", "structHylozoa_1_1__settingsStruct.html#a6886adee5edc0d7624c82436261f5366", null ],
    [ "verbose", "structHylozoa_1_1__settingsStruct.html#aef2838322548aae17e367074ccc20fca", null ]
];