var Interface_8cpp =
[
    [ "engine_create", "Interface_8cpp.html#a3317cd13065c6b1f7bb41fe5088b3c54", null ],
    [ "engine_init", "Interface_8cpp.html#a33ef690b2eec3b1f13c8663adb9a924c", null ],
    [ "engine_pause", "Interface_8cpp.html#a5205ef5f0ff3776750dc884b6fa7f3bd", null ],
    [ "engine_run", "Interface_8cpp.html#a1fdc79174456096732707ee1349a9896", null ],
    [ "engine_shutdown", "Interface_8cpp.html#aaac9124de90b73faa00fd83941a257db", null ],
    [ "engine_stop", "Interface_8cpp.html#ae7652abd9ef32117606cd52c6e6419c8", null ],
    [ "engine_unpause", "Interface_8cpp.html#aaa19f66a96cf588549434e80faf65d3a", null ],
    [ "generate_uuid", "Interface_8cpp.html#a99fd5c81057c4b6e1789b062b0404fbd", null ],
    [ "layer_create", "Interface_8cpp.html#a650b12ce0753e3e9c0ef46f497310e32", null ],
    [ "layer_destroy", "Interface_8cpp.html#a66fd05d2b88b5c37611dfc15d3469092", null ],
    [ "layer_list", "Interface_8cpp.html#ab2422e00f64c2c33f39e4d7d36229cce", null ],
    [ "scene_create", "Interface_8cpp.html#a1c1f2524690bd5c0d0d74b8c8c82d2cb", null ],
    [ "scene_destroy", "Interface_8cpp.html#a898f46a474c017d7d06f94f5558e5a4a", null ],
    [ "scene_destroy_name", "Interface_8cpp.html#a32c9dc5e6095ac31ca2d71ea1fc87429", null ],
    [ "scene_destroy_uuid", "Interface_8cpp.html#a3176bef93c0e65acb7c70ecf2acf676d", null ],
    [ "scene_load", "Interface_8cpp.html#aab8fad60a0b401e50fe06ebb9fb0d847", null ],
    [ "scene_load_name", "Interface_8cpp.html#aa15e5b102793b74491fc7f5589916ea8", null ],
    [ "scene_load_uuid", "Interface_8cpp.html#a949728400f75884104412421486a5b4a", null ],
    [ "scene_unload", "Interface_8cpp.html#a4aaf42bca6c8349e0bf32eb81ae65e40", null ],
    [ "scene_unload_name", "Interface_8cpp.html#af0816a8ec8938650cf532ad5549d900e", null ],
    [ "scene_unload_uuid", "Interface_8cpp.html#a937b70ce76d3a74c911f85861144c3f5", null ]
];