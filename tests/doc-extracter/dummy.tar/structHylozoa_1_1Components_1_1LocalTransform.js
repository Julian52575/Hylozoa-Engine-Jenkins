var structHylozoa_1_1Components_1_1LocalTransform =
[
    [ "position", "structHylozoa_1_1Components_1_1LocalTransform.html#a5b064e2d9e5a7878fad03946a5b87e3a", null ],
    [ "rotation", "structHylozoa_1_1Components_1_1LocalTransform.html#af8fab712d50647a1b1d5cbe3cf264a4c", null ],
    [ "scale", "structHylozoa_1_1Components_1_1LocalTransform.html#a44020abd78b38c2ec79a083cc89fa478", null ]
];