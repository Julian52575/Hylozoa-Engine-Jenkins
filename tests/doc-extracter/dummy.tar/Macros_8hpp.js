var Macros_8hpp =
[
    [ "API_EXPORT", "Macros_8hpp.html#a5e3652cae8b48c1ad174f0b06bbd06d0", null ],
    [ "ENGINE_PTR", "Macros_8hpp.html#a70ab139bed99b2b5372697ef0a414bae", null ]
];