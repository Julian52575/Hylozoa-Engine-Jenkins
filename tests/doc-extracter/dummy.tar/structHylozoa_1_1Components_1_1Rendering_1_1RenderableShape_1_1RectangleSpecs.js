var structHylozoa_1_1Components_1_1Rendering_1_1RenderableShape_1_1RectangleSpecs =
[
    [ "height", "structHylozoa_1_1Components_1_1Rendering_1_1RenderableShape_1_1RectangleSpecs.html#a76f0b3af62d343af1be3ee4eff2efd9e", null ],
    [ "width", "structHylozoa_1_1Components_1_1Rendering_1_1RenderableShape_1_1RectangleSpecs.html#a057790986a38f60ef312574287cc9879", null ]
];