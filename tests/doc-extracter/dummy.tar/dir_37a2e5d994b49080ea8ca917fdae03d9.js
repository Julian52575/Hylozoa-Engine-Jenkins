var dir_37a2e5d994b49080ea8ca917fdae03d9 =
[
    [ "API", "dir_b4f8cd03f74f1881fddbdcfe814703af.html", "dir_b4f8cd03f74f1881fddbdcfe814703af" ],
    [ "Components", "dir_8b68ebfaf6189f4a7b3b1c0e4271142d.html", "dir_8b68ebfaf6189f4a7b3b1c0e4271142d" ],
    [ "Core", "dir_33c58eaa183c7b222defe282a5ecbe43.html", "dir_33c58eaa183c7b222defe282a5ecbe43" ],
    [ "Placeholder", "dir_acb636100d8b24ce901c3bc1c19b9499.html", "dir_acb636100d8b24ce901c3bc1c19b9499" ],
    [ "SDL", "dir_678581fb396b458508d910d1ad100951.html", "dir_678581fb396b458508d910d1ad100951" ],
    [ "Systems", "dir_3d371e524791def1e897c8f84e38f525.html", "dir_3d371e524791def1e897c8f84e38f525" ]
];