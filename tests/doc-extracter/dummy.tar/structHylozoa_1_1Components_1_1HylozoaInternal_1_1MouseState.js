var structHylozoa_1_1Components_1_1HylozoaInternal_1_1MouseState =
[
    [ "buttonsHeld", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1MouseState.html#a280c4fb6d7c50072d421dbc4585e69f0", null ],
    [ "buttonsPressed", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1MouseState.html#a25e3808ad8194bea2c7a1f38ae1c7e36", null ],
    [ "buttonsReleased", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1MouseState.html#aa9c0a3c752069fb504a5fdcd0ab3351e", null ],
    [ "wheelX", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1MouseState.html#ab2f0b6979251ff561c76cf24d581ea5b", null ],
    [ "wheelY", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1MouseState.html#ae241be914b11ab8a5a9bcf0e3c2d1ef7", null ],
    [ "x", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1MouseState.html#ad81b425d1e64a7319f7d4b45d12207e8", null ],
    [ "y", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1MouseState.html#a83589ab3740e0ad3d0905ff759c9a674", null ]
];