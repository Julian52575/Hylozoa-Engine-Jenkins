var structHylozoa_1_1Components_1_1HylozoaInternal_1_1EngineState =
[
    [ "State", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1EngineState.html#aa391394cc713f60dc606f33289a032c7", [
      [ "RUNNING", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1EngineState.html#aa391394cc713f60dc606f33289a032c7a43491564ebcfd38568918efbd6e840fd", null ],
      [ "PAUSED", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1EngineState.html#aa391394cc713f60dc606f33289a032c7a99b2439e63f73ad515f7ab2447a80673", null ],
      [ "STOPPED", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1EngineState.html#aa391394cc713f60dc606f33289a032c7a09d4d696b4e935115b9313e3c412509a", null ]
    ] ],
    [ "currentState", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1EngineState.html#a5c70ac5dcf51bb4875eb0685b2cab264", null ]
];