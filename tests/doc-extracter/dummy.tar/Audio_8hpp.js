var Audio_8hpp =
[
    [ "Hylozoa::Audio", "classHylozoa_1_1Audio.html", "classHylozoa_1_1Audio" ],
    [ "Hylozoa::MAX_TRACKS", "namespaceHylozoa.html#a8752a74290c306a6b739267f1098ec42", null ]
];