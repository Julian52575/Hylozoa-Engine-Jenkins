var SDL__Manager_8hpp =
[
    [ "Hylozoa::SDL::SDL_Manager", "classHylozoa_1_1SDL_1_1SDL__Manager.html", "classHylozoa_1_1SDL_1_1SDL__Manager" ],
    [ "RENDERER_WINDOW_HEIGHT", "SDL__Manager_8hpp.html#a001e7ac693afb44a707bdf7dbfb6885d", null ],
    [ "RENDERER_WINDOW_WIDTH", "SDL__Manager_8hpp.html#ab0b9b66e7184eb836232f6dd91cc8121", null ]
];