var Placeholder_8hpp =
[
    [ "Hylozoa::Placeholder", "classHylozoa_1_1Placeholder.html", "classHylozoa_1_1Placeholder" ]
];