var structHylozoa_1_1Components_1_1HylozoaInternal_1_1EngineEvents =
[
    [ "pauseRequested", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1EngineEvents.html#addd4f9256d66ce54cda6b8160e8f2362", null ],
    [ "resumeRequested", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1EngineEvents.html#af5d6b766b4884b2ab92d07fc3c2b8b86", null ],
    [ "shouldQuit", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1EngineEvents.html#a8111468d29baf3a3bb8e736bda3decba", null ]
];