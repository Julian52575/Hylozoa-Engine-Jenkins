var annotated_dup =
[
    [ "Hylozoa", "namespaceHylozoa.html", [
      [ "Components", "namespaceHylozoa_1_1Components.html", [
        [ "HylozoaInternal", "namespaceHylozoa_1_1Components_1_1HylozoaInternal.html", [
          [ "EngineState", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1EngineState.html", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1EngineState" ],
          [ "EngineEvents", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1EngineEvents.html", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1EngineEvents" ],
          [ "OnSceneLoaded", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1OnSceneLoaded.html", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1OnSceneLoaded" ],
          [ "OnSceneUnloaded", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1OnSceneUnloaded.html", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1OnSceneUnloaded" ],
          [ "OnNoiseEvent", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1OnNoiseEvent.html", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1OnNoiseEvent" ],
          [ "EventsDispatcher", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1EventsDispatcher.html", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1EventsDispatcher" ],
          [ "InputState", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1InputState.html", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1InputState" ],
          [ "MouseState", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1MouseState.html", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1MouseState" ],
          [ "GamepadState", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1GamepadState.html", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1GamepadState" ],
          [ "SceneState", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1SceneState.html", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1SceneState" ],
          [ "Time", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1Time.html", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1Time" ],
          [ "RenderTexture", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1RenderTexture.html", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1RenderTexture" ],
          [ "SceneTag", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1SceneTag.html", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1SceneTag" ],
          [ "SceneActiveTag", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1SceneActiveTag.html", null ],
          [ "Id", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1Id.html", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1Id" ],
          [ "Parent", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1Parent.html", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1Parent" ],
          [ "LocalToWorld", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1LocalToWorld.html", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1LocalToWorld" ],
          [ "Children", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1Children.html", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1Children" ]
        ] ],
        [ "Rendering", "namespaceHylozoa_1_1Components_1_1Rendering.html", [
          [ "Renderable", "structHylozoa_1_1Components_1_1Rendering_1_1Renderable.html", "structHylozoa_1_1Components_1_1Rendering_1_1Renderable" ],
          [ "RenderableShape", "structHylozoa_1_1Components_1_1Rendering_1_1RenderableShape.html", "structHylozoa_1_1Components_1_1Rendering_1_1RenderableShape" ],
          [ "AnimationSpecs", "structHylozoa_1_1Components_1_1Rendering_1_1AnimationSpecs.html", "structHylozoa_1_1Components_1_1Rendering_1_1AnimationSpecs" ],
          [ "Sprite", "structHylozoa_1_1Components_1_1Rendering_1_1Sprite.html", "structHylozoa_1_1Components_1_1Rendering_1_1Sprite" ]
        ] ],
        [ "MainListener", "structHylozoa_1_1Components_1_1MainListener.html", null ],
        [ "NoiseListener", "structHylozoa_1_1Components_1_1NoiseListener.html", "structHylozoa_1_1Components_1_1NoiseListener" ],
        [ "Camera", "structHylozoa_1_1Components_1_1Camera.html", "structHylozoa_1_1Components_1_1Camera" ],
        [ "Controllable", "structHylozoa_1_1Components_1_1Controllable.html", "structHylozoa_1_1Components_1_1Controllable" ],
        [ "RigidBodyComponent", "structHylozoa_1_1Components_1_1RigidBodyComponent.html", "structHylozoa_1_1Components_1_1RigidBodyComponent" ],
        [ "ColliderComponent", "structHylozoa_1_1Components_1_1ColliderComponent.html", "structHylozoa_1_1Components_1_1ColliderComponent" ],
        [ "BoxColliderComponent", "structHylozoa_1_1Components_1_1BoxColliderComponent.html", "structHylozoa_1_1Components_1_1BoxColliderComponent" ],
        [ "CircleColliderComponent", "structHylozoa_1_1Components_1_1CircleColliderComponent.html", "structHylozoa_1_1Components_1_1CircleColliderComponent" ],
        [ "CapsuleColliderComponent", "structHylozoa_1_1Components_1_1CapsuleColliderComponent.html", "structHylozoa_1_1Components_1_1CapsuleColliderComponent" ],
        [ "Name", "structHylozoa_1_1Components_1_1Name.html", "structHylozoa_1_1Components_1_1Name" ],
        [ "LocalTransform", "structHylozoa_1_1Components_1_1LocalTransform.html", "structHylozoa_1_1Components_1_1LocalTransform" ],
        [ "WorldTransform", "structHylozoa_1_1Components_1_1WorldTransform.html", "structHylozoa_1_1Components_1_1WorldTransform" ]
      ] ],
      [ "Resources", "namespaceHylozoa_1_1Resources.html", [
        [ "Texture", "classHylozoa_1_1Resources_1_1Texture.html", "classHylozoa_1_1Resources_1_1Texture" ],
        [ "Font", "classHylozoa_1_1Resources_1_1Font.html", "classHylozoa_1_1Resources_1_1Font" ],
        [ "Sound", "classHylozoa_1_1Resources_1_1Sound.html", "classHylozoa_1_1Resources_1_1Sound" ],
        [ "Music", "classHylozoa_1_1Resources_1_1Music.html", "classHylozoa_1_1Resources_1_1Music" ]
      ] ],
      [ "SDL", "namespaceHylozoa_1_1SDL.html", [
        [ "SDL_Manager", "classHylozoa_1_1SDL_1_1SDL__Manager.html", "classHylozoa_1_1SDL_1_1SDL__Manager" ]
      ] ],
      [ "Systems", "namespaceHylozoa_1_1Systems.html", [
        [ "AudioSystem", "classHylozoa_1_1Systems_1_1AudioSystem.html", "classHylozoa_1_1Systems_1_1AudioSystem" ],
        [ "Movement", "classHylozoa_1_1Systems_1_1Movement.html", "classHylozoa_1_1Systems_1_1Movement" ],
        [ "PhysicsSystem", "classHylozoa_1_1Systems_1_1PhysicsSystem.html", "classHylozoa_1_1Systems_1_1PhysicsSystem" ],
        [ "Renderer", "classHylozoa_1_1Systems_1_1Renderer.html", "classHylozoa_1_1Systems_1_1Renderer" ],
        [ "ParentChildSystem", "classHylozoa_1_1Systems_1_1ParentChildSystem.html", "classHylozoa_1_1Systems_1_1ParentChildSystem" ],
        [ "UpdateTransformSystem", "classHylozoa_1_1Systems_1_1UpdateTransformSystem.html", "classHylozoa_1_1Systems_1_1UpdateTransformSystem" ]
      ] ],
      [ "UUID", "classHylozoa_1_1UUID.html", "classHylozoa_1_1UUID" ],
      [ "Engine", "classHylozoa_1_1Engine.html", "classHylozoa_1_1Engine" ],
      [ "Entity", "classHylozoa_1_1Entity.html", "classHylozoa_1_1Entity" ],
      [ "Audio", "classHylozoa_1_1Audio.html", "classHylozoa_1_1Audio" ],
      [ "Input", "classHylozoa_1_1Input.html", "classHylozoa_1_1Input" ],
      [ "LayerMask", "classHylozoa_1_1LayerMask.html", "classHylozoa_1_1LayerMask" ],
      [ "LayerManager", "classHylozoa_1_1LayerManager.html", "classHylozoa_1_1LayerManager" ],
      [ "ResourcesManager", "classHylozoa_1_1ResourcesManager.html", "classHylozoa_1_1ResourcesManager" ],
      [ "Scene", "classHylozoa_1_1Scene.html", "classHylozoa_1_1Scene" ],
      [ "SceneManager", "classHylozoa_1_1SceneManager.html", "classHylozoa_1_1SceneManager" ],
      [ "SceneSerializer", "classHylozoa_1_1SceneSerializer.html", "classHylozoa_1_1SceneSerializer" ],
      [ "_settingsStruct", "structHylozoa_1_1__settingsStruct.html", "structHylozoa_1_1__settingsStruct" ],
      [ "Settings", "classHylozoa_1_1Settings.html", "classHylozoa_1_1Settings" ],
      [ "Time", "classHylozoa_1_1Time.html", "classHylozoa_1_1Time" ],
      [ "Placeholder", "classHylozoa_1_1Placeholder.html", "classHylozoa_1_1Placeholder" ],
      [ "CameraSystem", "classHylozoa_1_1CameraSystem.html", "classHylozoa_1_1CameraSystem" ],
      [ "SystemManager", "classHylozoa_1_1SystemManager.html", "classHylozoa_1_1SystemManager" ],
      [ "System", "classHylozoa_1_1System.html", "classHylozoa_1_1System" ],
      [ "RenderSystem", "classHylozoa_1_1RenderSystem.html", "classHylozoa_1_1RenderSystem" ]
    ] ],
    [ "std", "namespacestd.html", [
      [ "hash&lt; Hylozoa::UUID &gt;", "structstd_1_1hash_3_01Hylozoa_1_1UUID_01_4.html", "structstd_1_1hash_3_01Hylozoa_1_1UUID_01_4" ]
    ] ],
    [ "Color", "classColor.html", null ],
    [ "Events", "structEvents.html", null ],
    [ "Scene", "structScene.html", null ]
];