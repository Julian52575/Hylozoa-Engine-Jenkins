var structHylozoa_1_1Components_1_1BoxColliderComponent =
[
    [ "halfHeight", "structHylozoa_1_1Components_1_1BoxColliderComponent.html#a992919b113ce3bba933d538cc0cf5ce1", null ],
    [ "halfWidth", "structHylozoa_1_1Components_1_1BoxColliderComponent.html#a7351ee6e9fb2721b4b4bde372eaf9e96", null ]
];