var searchData=
[
  ['engine_5fptr_0',['ENGINE_PTR',['../Macros_8hpp.html#a70ab139bed99b2b5372697ef0a414bae',1,'Macros.hpp']]]
];
