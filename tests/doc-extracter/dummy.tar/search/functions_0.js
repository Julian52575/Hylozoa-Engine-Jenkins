var searchData=
[
  ['_5freadfromfile_0',['_readFromFile',['../Settings_8cpp.html#a83b5dadeb8ce0fc65cdbc2997e079e8f',1,'_readFromFile(std::istream &amp;jsonStream, json &amp;outJson):&#160;Settings.cpp'],['../Settings_8cpp.html#a478f1f5d7883189783aaf4c70adb336c',1,'_readFromFile(const std::string &amp;path, json &amp;outJson):&#160;Settings.cpp']]],
  ['_5fsettingsstruct_1',['_settingsStruct',['../structHylozoa_1_1__settingsStruct.html#a4820a4998b22aca0e283a9f501e95cfc',1,'Hylozoa::_settingsStruct::_settingsStruct()=default'],['../structHylozoa_1_1__settingsStruct.html#acbfc11c72eec9664ba32523833fdb0fb',1,'Hylozoa::_settingsStruct::_settingsStruct(json &amp;settingsJson)']]]
];
