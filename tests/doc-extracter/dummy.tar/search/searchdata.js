var indexSectionsWithContent =
{
  0: "_abcdefghijklmnoprstuvwxyz~",
  1: "_abcefghilmnoprstuw",
  2: "hs",
  3: "aceilmprstuv",
  4: "_abcdefghilmnoprstuvw~",
  5: "_abcdefghiklmnoprstvwxyz",
  6: "cfjlmstv",
  7: "es",
  8: "chlnprstu",
  9: "aer",
  10: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "defines",
  10: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Macros",
  10: "Modules"
};

