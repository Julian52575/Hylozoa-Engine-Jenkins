var searchData=
[
  ['_5fsettingsstruct_0',['_settingsStruct',['../structHylozoa_1_1__settingsStruct.html',1,'Hylozoa']]]
];
