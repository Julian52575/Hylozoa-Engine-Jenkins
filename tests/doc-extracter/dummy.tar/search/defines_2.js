var searchData=
[
  ['renderer_5fwindow_5fheight_0',['RENDERER_WINDOW_HEIGHT',['../SDL__Manager_8hpp.html#a001e7ac693afb44a707bdf7dbfb6885d',1,'SDL_Manager.hpp']]],
  ['renderer_5fwindow_5fwidth_1',['RENDERER_WINDOW_WIDTH',['../SDL__Manager_8hpp.html#ab0b9b66e7184eb836232f6dd91cc8121',1,'SDL_Manager.hpp']]]
];
