var searchData=
[
  ['_5fisactive_0',['_isActive',['../classHylozoa_1_1System.html#ae7fc21ed5da3ad29f11b41a17d7b04e2',1,'Hylozoa::System']]],
  ['_5fname_1',['_name',['../classHylozoa_1_1Systems_1_1Movement.html#a9dbfc4de5bc65e73cb7de36ce6cb878d',1,'Hylozoa::Systems::Movement::_name'],['../classHylozoa_1_1Systems_1_1Renderer.html#aa311c3ee53a1d0f1ea60b4c240b1559b',1,'Hylozoa::Systems::Renderer::_name']]],
  ['_5fpriority_2',['_priority',['../classHylozoa_1_1System.html#aa394aca1a3741d0dc346370b745f2e6d',1,'Hylozoa::System::_priority'],['../classHylozoa_1_1Systems_1_1Movement.html#abde6392216836edc82271491377baa28',1,'Hylozoa::Systems::Movement::_priority'],['../classHylozoa_1_1Systems_1_1Renderer.html#a3060a49817144abb4f17ddd2474c1df0',1,'Hylozoa::Systems::Renderer::_priority']]],
  ['_5fregistry_3',['_registry',['../classHylozoa_1_1System.html#a78086d4f4595b92da75bc962fdaeb09d',1,'Hylozoa::System']]]
];
