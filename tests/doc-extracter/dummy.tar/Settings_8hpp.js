var Settings_8hpp =
[
    [ "Hylozoa::_settingsStruct", "structHylozoa_1_1__settingsStruct.html", "structHylozoa_1_1__settingsStruct" ],
    [ "Hylozoa::Settings", "classHylozoa_1_1Settings.html", "classHylozoa_1_1Settings" ],
    [ "operator<<", "Settings_8hpp.html#a856ba56313ef7531f90fdc657d64a79f", null ],
    [ "operator<<", "Settings_8hpp.html#a21002f9e0a9ecfe6ae9afa92f93409aa", null ]
];