var structHylozoa_1_1Components_1_1HylozoaInternal_1_1SceneState =
[
    [ "State", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1SceneState.html#aa2ccebfd5e91ff110e0770f7e400c720", [
      [ "LOADED", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1SceneState.html#aa2ccebfd5e91ff110e0770f7e400c720ab638272ceeff54912f043465e9a28c9b", null ],
      [ "UNLOADED", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1SceneState.html#aa2ccebfd5e91ff110e0770f7e400c720a795b8a51556d0b2cf4fbc11a896f6269", null ]
    ] ],
    [ "states", "structHylozoa_1_1Components_1_1HylozoaInternal_1_1SceneState.html#a6280b89457672e6a87e6c2c67f94f06a", null ]
];