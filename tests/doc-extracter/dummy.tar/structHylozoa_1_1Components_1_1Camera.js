var structHylozoa_1_1Components_1_1Camera =
[
    [ "cullingMask", "structHylozoa_1_1Components_1_1Camera.html#a1a6b495de48a28fc04ff95b2e99b100a", null ],
    [ "isUI", "structHylozoa_1_1Components_1_1Camera.html#aeb93cfeba65b909217f94c62637513e9", null ],
    [ "offset", "structHylozoa_1_1Components_1_1Camera.html#a7f29878ce05cc7fe16ff011d61c31f80", null ],
    [ "order", "structHylozoa_1_1Components_1_1Camera.html#a11e1c75e644907462115e65b182814c0", null ],
    [ "viewportSize", "structHylozoa_1_1Components_1_1Camera.html#a4dff7b00b01871df47b8841a40d96ce2", null ],
    [ "zoom", "structHylozoa_1_1Components_1_1Camera.html#a8e1761ad2d7c337d5398445c01aeaca4", null ]
];