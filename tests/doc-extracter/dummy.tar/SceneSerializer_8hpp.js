var SceneSerializer_8hpp =
[
    [ "Hylozoa::SceneSerializer", "classHylozoa_1_1SceneSerializer.html", "classHylozoa_1_1SceneSerializer" ]
];